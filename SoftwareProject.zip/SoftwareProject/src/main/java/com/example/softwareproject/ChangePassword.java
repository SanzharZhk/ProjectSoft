package com.example.softwareproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class ChangePassword implements Initializable {
    @FXML
    private ImageView image;
    @FXML
    private Button back;

    @FXML
    private Button change;

    @FXML
    private TextField gmail;

    @FXML
    private Text gmailIsEmpty;

    @FXML
    private ProgressIndicator loading;

    @FXML
    private AnchorPane pane;

    @FXML
    private PasswordField newPassword;

    @FXML
    private Text passwordIsEmpty;

    @FXML
    private Text text;

    @FXML
    private Text text1;

    @FXML
    private TextField username;

    @FXML
    private Text usernameIsEmpty;

    @FXML
    void back(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage primaryStage = (Stage)((Node)event.getSource()).getScene().getWindow();
        primaryStage.setScene(new Scene(root));
        primaryStage.show();

    }

    @FXML
    void change(ActionEvent event) {
        if(username.getText().isEmpty()&&newPassword.getText().isEmpty()&&gmail.getText().isEmpty()){
            usernameIsEmpty.setVisible(true);
            passwordIsEmpty.setVisible(true);
            gmailIsEmpty.setVisible(true);
        }
        else if(username.getText().isEmpty()&&!newPassword.getText().isEmpty()&&!gmail.getText().isEmpty()){
            usernameIsEmpty.setVisible(true);
            passwordIsEmpty.setVisible(false);
            gmailIsEmpty.setVisible(false);
        }
        else if(!username.getText().isEmpty()&&newPassword.getText().isEmpty()&&!gmail.getText().isEmpty()){
            usernameIsEmpty.setVisible(false);
            passwordIsEmpty.setVisible(true);
            gmailIsEmpty.setVisible(false);
        }
        else if(!username.getText().isEmpty()&&!newPassword.getText().isEmpty()&&gmail.getText().isEmpty()){
            usernameIsEmpty.setVisible(false);
            passwordIsEmpty.setVisible(false);
            gmailIsEmpty.setVisible(true);
        }
        else if(!username.getText().isEmpty()&&newPassword.getText().isEmpty()&&gmail.getText().isEmpty()){
            usernameIsEmpty.setVisible(false);
            passwordIsEmpty.setVisible(true);
            gmailIsEmpty.setVisible(true);
        }
        else if(username.getText().isEmpty()&&!newPassword.getText().isEmpty()&&gmail.getText().isEmpty()){
            usernameIsEmpty.setVisible(true);
            passwordIsEmpty.setVisible(false);
            gmailIsEmpty.setVisible(true);
        }
        else if(username.getText().isEmpty()&&newPassword.getText().isEmpty()&&!gmail.getText().isEmpty()){
            usernameIsEmpty.setVisible(true);
            passwordIsEmpty.setVisible(true);
            gmailIsEmpty.setVisible(false);
        }
        else{
            usernameIsEmpty.setVisible(false);
            passwordIsEmpty.setVisible(false);
            gmailIsEmpty.setVisible(false);
            try {change();
            } catch (IOException e) {
                throw new RuntimeException(e);}
        }
}
    @FXML
    void change() throws IOException {
        File file = new File("Folder/"+username.getText()+".txt");
        Stage stage = new Stage();
        stage.setTitle("Error");
        Text error = new Text();
        error.setFill(Color.web("#ff5a5a"));
        error.setFont(Font.font("", FontWeight.BOLD, FontPosture.REGULAR, 12));
        if(username.getText().equals(newPassword.getText())){
            error.setText("Password Matched");
            stage.setScene(new Scene(new StackPane(error), 200, 50));
            stage.show();
        }
        else if(!file.exists()){
            error.setText("Username or gmail is not correct!");
            stage.setScene(new Scene(new StackPane(error), 250, 50));
            stage.show();
        }
        else if(newPassword.getText().length()>9){
            error.setText("Limit password is 9 characters");
            stage.setScene(new Scene(new StackPane(error), 300, 50));
            stage.show();}
        else if(file.exists()){
            FileInputStream inputStream = new FileInputStream(file);
            int i = -1;
            String fileString = "";
            while ((i=inputStream.read())!=-1){
                fileString+=(char)i;
            }
            String[] lines = fileString.split("\n");
            if(lines[2].substring(7).equals(gmail.getText())){
                lines[1] = lines[1].substring(0, 10)+newPassword.getText();
                FileOutputStream outputStream = new FileOutputStream(file);
                byte[] buffer;
                for(String n : lines){
                    buffer = (n+"\n").getBytes();
                    outputStream.write(buffer);
                }
                outputStream.close();
                Text message = new Text("password saved");
                message.setFill(Color.web("#4fe76b"));
                message.setFont(Font.font("", FontWeight.BOLD, FontPosture.REGULAR, 12));
                stage.setScene(new Scene(new StackPane(message),200, 50));
                stage.show();
            }
            else{
                error.setText("Username or gmail is not correct");
                stage.setScene(new Scene(new StackPane(error), 250, 50));
                stage.show();}
        }
}

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        image.setImage(new Image("C:\\Users\\sanzh\\Downloads\\Telegram Desktop\\IMG_20231222_030834.jpg"));
    }
}

