package com.example.softwareproject;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

interface OrderStatusObserver {
    void update(String status) throws IOException;
}

class OrderStatusSubject {
    private List<OrderStatusObserver> observers = new ArrayList<>();

    public void updateObservers() {
        String filePath = "Folder/allVisits";
        String userLogin = null;
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String current;
            while ((current = reader.readLine()) != null) {
                userLogin = current;
                User user = new User(userLogin);
                if(!observers.contains(user))
                    observers.add(user);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void addObserver(OrderStatusObserver observer) {
        if(!observers.contains(observer))
         observers.add(observer);
    }

    public void notifyObservers(String message) {
        for (OrderStatusObserver observer : observers) {
            try {
                observer.update(message);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}

class User implements OrderStatusObserver {
    private String login;
    public User(String login) {
        this.login = login;
    }
    @Override
    public void update(String message) throws IOException {
         String filePath = "Folder/notify";
            try (FileWriter fileWriter = new FileWriter(filePath, false);
                 BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                bufferedWriter.write("Notification: "+login+" "+message);
                bufferedWriter.newLine();
            } catch (IOException e) {
                System.err.println("Error writing to the file: " + e.getMessage());
            }


        }
}
