package com.example.softwareproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URL;
import java.util.ResourceBundle;

public class SignUp implements Initializable {

    @FXML
    private RadioButton female;

    @FXML
    private TextField gmail;
    @FXML
    private ImageView imageView;

    @FXML
    private ProgressIndicator loading;

    @FXML
    private Button login;

    @FXML
    private RadioButton male;

    @FXML
    private RadioButton other;

    @FXML
    private AnchorPane pane;

    @FXML
    private PasswordField password;

    @FXML
    private Text passwordIsEmpty;

    @FXML
    private Button signUp;

    @FXML
    private Text text;

    @FXML
    private Text text1;

    @FXML
    private TextField username;

    @FXML
    private Text usernameIsEmpty;
    @FXML
    private Text gmailIsEmpty;

    @FXML
    public void signUp(ActionEvent event) {
        if(username.getText().isEmpty()&&password.getText().isEmpty()&&gmail.getText().isEmpty()){
            usernameIsEmpty.setVisible(true);
            passwordIsEmpty.setVisible(true);
            gmailIsEmpty.setVisible(true);
        }
        else if(username.getText().isEmpty()&&!password.getText().isEmpty()&&!gmail.getText().isEmpty()){
            usernameIsEmpty.setVisible(true);
            passwordIsEmpty.setVisible(false);
            gmailIsEmpty.setVisible(false);
        }
        else if(!username.getText().isEmpty()&&password.getText().isEmpty()&&!gmail.getText().isEmpty()){
            usernameIsEmpty.setVisible(false);
            passwordIsEmpty.setVisible(true);
            gmailIsEmpty.setVisible(false);
        }
        else if(!username.getText().isEmpty()&&!password.getText().isEmpty()&&gmail.getText().isEmpty()){
            usernameIsEmpty.setVisible(false);
            passwordIsEmpty.setVisible(false);
            gmailIsEmpty.setVisible(true);
        }
        else if(!username.getText().isEmpty()&&password.getText().isEmpty()&&gmail.getText().isEmpty()){
            usernameIsEmpty.setVisible(false);
            passwordIsEmpty.setVisible(true);
            gmailIsEmpty.setVisible(true);
        }
        else if(username.getText().isEmpty()&&!password.getText().isEmpty()&&gmail.getText().isEmpty()){
            usernameIsEmpty.setVisible(true);
            passwordIsEmpty.setVisible(false);
            gmailIsEmpty.setVisible(true);
        }
        else if(username.getText().isEmpty()&&password.getText().isEmpty()&&!gmail.getText().isEmpty()){
            usernameIsEmpty.setVisible(true);
            passwordIsEmpty.setVisible(true);
            gmailIsEmpty.setVisible(false);
        }
        else{
            usernameIsEmpty.setVisible(false);
            passwordIsEmpty.setVisible(false);
            gmailIsEmpty.setVisible(false);
            try {CheckData();
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);}
        }
    }
    void CheckData() throws FileNotFoundException, IOException{
        Stage stage = new Stage();
        Text error = new Text();
        stage.setTitle("Error");
        error.setFill(Color.web("#ff5a5a"));
        error.setFont(Font.font("", FontWeight.BOLD, FontPosture.REGULAR, 12));
        if(username.getText().equals(password.getText())){
            error.setText("Password Matched");
            stage.setScene(new Scene(new StackPane(error), 200, 50));
            stage.show();
        }
        else if(username.getText().length()>9||password.getText().length()>9||gmail.getText().length()>9){
            error.setText("Limit username, password and email are 9 characters");
            stage.setScene(new Scene(new StackPane(error), 300, 50));
            stage.show();
        }
        else{
            readFile();}
    }
    void readFile() {
        File file = new File("Folder/"+username.getText()+".txt");
        Stage stage = new Stage();
        Text message = new Text();
        message.setFill(Color.web("#4fe76b"));
        message.setFont(Font.font("", FontWeight.BOLD, FontPosture.REGULAR, 12));
        if(file.exists()){
            message.setText("File exist");
            stage.setScene(new Scene(new StackPane(message), 200, 50));
            stage.show();}
        else{
            message.setText("File created");
            stage.setScene(new Scene(new StackPane(message), 200, 50));
            stage.show();
            createFolder();
            addData();
        }
    }
    void createFolder(){
        File file = new File("Folder/"+username.getText()+".txt");
        try {
            file.createNewFile();
        } catch (IOException ex) {
            throw new RuntimeException(ex);}
    }
    void addData(){
        RandomAccessFile randomAccessFile = null;
        try {
            randomAccessFile = new RandomAccessFile(new File("Folder/"+username.getText()+".txt"), "rw");
            randomAccessFile.writeBytes("UserName: "+username.getText()+"\n");
            randomAccessFile.writeBytes("Password: "+password.getText()+"\n");
            randomAccessFile.writeBytes("Gmail: "+gmail.getText()+"\n");
            if(male.isSelected())
                randomAccessFile.writeBytes("Gender: "+male.getText()+"\n");
            else if(female.isSelected())
                randomAccessFile.writeBytes("Gender: "+female.getText()+"\n");
            else
                randomAccessFile.writeBytes("Gender: "+other.getText()+"\n");
            randomAccessFile.writeBytes("Orders: \n");
            randomAccessFile.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        } catch (IOException e) {
            System.out.println("IOException");
        }
    }
    @FXML
    public void logIn(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        imageView.setImage(new Image("C:\\Users\\sanzh\\Downloads\\Telegram Desktop\\IMG_20231222_030808.jpg"));
    }
}
