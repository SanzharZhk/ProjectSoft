package com.example.softwareproject;

 interface Product {
    String getType();
    double getPrice();
}

class Sweatshirt implements Product {
    @Override
    public String getType() {
        return "Sweatshirt";
    }
    @Override
    public double getPrice() {
        return 18000;
    }
}

class Hoodie implements Product {
    @Override
    public String getType() {
        return "Hoodie";
    }
    @Override
    public double getPrice() {
        return 22000;
    }
}
class Tshirt implements Product {
    @Override
    public String getType() {
        return "T-shirt";
    }
    @Override
    public double getPrice() {
        return 10000;
    }
}

class ALKI implements Product {
    @Override
    public String getType() {
        return "ALKI";
    }
    @Override
    public double getPrice() {
        return 17000;
    }
}
class Shopper implements Product {
    @Override
    public String getType() {
        return "Shopper";
    }
    @Override
    public double getPrice() {
        return 8000;
    }
}
class Cap implements Product {
    @Override
    public String getType() {
        return "Cap";
    }
    @Override
    public double getPrice() {
        return 7000;
    }
}

class Cup implements Product {
    @Override
    public String getType() {
        return "Cup";
    }
    @Override
    public double getPrice() {
        return 5000;
    }
}

class Panama implements Product {
    @Override
    public String getType() {
        return "Panama";
    }
    @Override
    public double getPrice() {
        return 6000;
    }
}

class ProductFactory {
    public Product createProduct(String productType) {
        if ("Sweatshirt".equalsIgnoreCase(productType)) {
            return new Sweatshirt();
        }
        else if ("T-shirt".equalsIgnoreCase(productType)) {
            return new Tshirt();
        }
        else if ("Hoodie".equalsIgnoreCase(productType)) {
            return new Hoodie();
        }
        else if ("Cup".equalsIgnoreCase(productType)) {
            return new Cup();
        }
        else if ("Cap".equalsIgnoreCase(productType)) {
            return new Cap();
        }
        else if ("Panama".equalsIgnoreCase(productType)) {
            return new Panama();
        }
        else if ("Shopper".equalsIgnoreCase(productType)) {
            return new Shopper();
        }
        else if ("ALKI".equalsIgnoreCase(productType)) {
            return new ALKI();
        }
        else {
            throw new IllegalArgumentException("Invalid product type");
        }
    }
}

