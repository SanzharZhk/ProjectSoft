package com.example.softwareproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.awt.Desktop;

public class Login {

    @FXML
    private Text forgotPassword;

    @FXML
    private Button instagram;

    @FXML
    private ProgressIndicator loading;

    @FXML
    private Button login;

    @FXML
    private PasswordField password;

    @FXML
    private Text passwordIsEmpty;

    @FXML
    private Button signUp;

    @FXML
    private Text text;

    @FXML
    private Text text1;

    @FXML
    private TextField username;

    @FXML
    private Text usernameIsEmpty;

    @FXML
    void forgotPassword(MouseEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("changePassword.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    void instagramIn(ActionEvent event) {
        if (Desktop.isDesktopSupported()) {
            Desktop desktop = Desktop.getDesktop();
            try {
                URI uri = new URI("https://www.instagram.com/sdu.store/");
                desktop.browse(uri);
            } catch (IOException excp) {
                excp.printStackTrace();
            } catch (URISyntaxException excp) {
                excp.printStackTrace();
            }
        }
    }

    @FXML
    void logIn(ActionEvent event) throws IOException {
            if(username.getText().isEmpty()&&password.getText().isEmpty()){
                usernameIsEmpty.setVisible(true);
                passwordIsEmpty.setVisible(true);
            }
            else if(username.getText().isEmpty()&&!password.getText().isEmpty()){
                usernameIsEmpty.setVisible(true);
                passwordIsEmpty.setVisible(false);}
            else if(!username.getText().isEmpty()&&password.getText().isEmpty()){
                usernameIsEmpty.setVisible(false);
                passwordIsEmpty.setVisible(true);
            }
            else{
                usernameIsEmpty.setVisible(false);
                passwordIsEmpty.setVisible(false);
                logic(event);
            }
    }

    private void logic(ActionEvent event) throws IOException {
        File file = new File("Folder/"+username.getText()+".txt");
        Stage stage = new Stage();
        stage.setTitle("Error");
        Text error = new Text();
        error.setFill(Color.web("#ff5a5a"));
        error.setFont(Font.font("", FontWeight.BOLD, FontPosture.REGULAR, 12));
        if(username.getText().equals(password.getText())){
            error.setText("Password Matched");
            stage.setScene(new Scene(new StackPane(error), 200, 50));
            stage.show();
        }
        else if(!file.exists()){
            error.setText("Username or password is not correct");
            stage.setScene(new Scene(new StackPane(error), 250, 50));
            stage.show();
        }
        else if(file.exists()){
            FileInputStream inputStream = new FileInputStream(file);
            int i = -1;
            String fileStr = "";
            while ((i=inputStream.read())!=-1){
                fileStr+=(char)i;
            }
            String[] line = fileStr.split("\n");
            if(line[1].substring(10).equals(password.getText())){
                String filePath = "Folder/allVisits";
                try (FileWriter fileWriter = new FileWriter(filePath, true);
                     BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                    bufferedWriter.write(username.getText());
                    bufferedWriter.newLine();
                } catch (IOException e) {
                    System.err.println("Error writing to the file: " + e.getMessage());
                }
                loginAction(event);
            }
            else{
                error.setText("Username or password is not correct");
                stage.setScene(new Scene(new StackPane(error), 250, 50));
                stage.show();}
        }
    }
    @FXML
    void loginAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Store.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
    @FXML
    void signUp(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("signUp.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

}
