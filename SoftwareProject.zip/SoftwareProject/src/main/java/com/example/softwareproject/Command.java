package com.example.softwareproject;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

interface Command {
    void execute() throws IOException;
}

class OrderCommand {
    public void execute(Command command) throws IOException {
        command.execute();
    }
}

class PlaceOrderCommand implements Command {
    private User user;
    private Product product;


    public PlaceOrderCommand(Product product, User user) {
        this.product = product;
        this.user= user;
    }

    @Override
    public void execute() throws IOException {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();

        String filePath = "Folder/allVisits";
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String userLogin = null;
            String current;
            while ((current = reader.readLine()) != null) {
                userLogin = current;
            }
            String ordered = "Folder/" + userLogin + ".txt";
            try (FileWriter fileWriter = new FileWriter(ordered, true);
                 BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                bufferedWriter.write(dtf.format(now)+" you ordered " + product.getType());
                bufferedWriter.newLine();
            } catch (IOException e) {
                System.err.println("Error writing to the file: " + e.getMessage());
            }
        }
    }
}
