package com.example.softwareproject;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ResourceBundle;

public class Store implements Initializable {
    @FXML
    private RadioButton ALKI1;

    @FXML
    private RadioButton ALKI2;

    @FXML
    private RadioButton ALKI3;

    @FXML
    private RadioButton ALKI4;

    @FXML
    private RadioButton ALKI5;

    @FXML
    private RadioButton ALKI6;

    @FXML
    private RadioButton ALKI7;

    @FXML
    private RadioButton Cap1;

    @FXML
    private RadioButton Cap2;

    @FXML
    private RadioButton Cup1;

    @FXML
    private RadioButton Cup2;

    @FXML
    private RadioButton Cup3;

    @FXML
    private RadioButton Cup4;

    @FXML
    private RadioButton Hoodie1;

    @FXML
    private RadioButton Hoodie2;

    @FXML
    private RadioButton Hoodie3;

    @FXML
    private RadioButton Hoodie4;

    @FXML
    private RadioButton Hoodie5;

    @FXML
    private RadioButton Hoodie6;

    @FXML
    private RadioButton Hoodie7;

    @FXML
    private RadioButton Hoodie8;

    @FXML
    private RadioButton L;

    @FXML
    private RadioButton M;

    @FXML
    private RadioButton Panama1;

    @FXML
    private RadioButton Panama2;

    @FXML
    private RadioButton S;

    @FXML
    private RadioButton Shopper1;

    @FXML
    private RadioButton Shopper2;

    @FXML
    private RadioButton Shopper3;

    @FXML
    private RadioButton Shopper4;

    @FXML
    private RadioButton Shopper5;

    @FXML
    private RadioButton Shopper6;

    @FXML
    private RadioButton Shopper7;

    @FXML
    private RadioButton Shopper8;

    @FXML
    private RadioButton Sweatshirt1;

    @FXML
    private RadioButton Sweatshirt2;

    @FXML
    private RadioButton Sweatshirt3;

    @FXML
    private RadioButton Sweatshirt4;

    @FXML
    private RadioButton Sweatshirt5;

    @FXML
    private RadioButton Sweatshirt6;

    @FXML
    private RadioButton Sweatshirt7;

    @FXML
    private RadioButton Tshirt1;

    @FXML
    private RadioButton Tshirt2;

    @FXML
    private RadioButton Tshirt3;

    @FXML
    private RadioButton Tshirt4;

    @FXML
    private RadioButton Tshirt5;

    @FXML
    private RadioButton Tshirt6;

    @FXML
    private Button buy;

    @FXML
    private ToggleGroup group;

    @FXML
    private TitledPane historyOfOrders;

    @FXML
    private ImageView im1;
    @FXML
    private Button priceBut;

    @FXML
    private ToggleGroup wearGroup;

    @FXML
    private Button instagram;

    @FXML
    private TextArea orders;

    @FXML
    private AnchorPane pane;

    @FXML
    private TextField price;

    @FXML
    private Text text;

    @FXML
    private Text text1;
    @FXML
    private ImageView sdu1;

    @FXML
    private ImageView sdu2;

    @FXML
    private ImageView sdu3;

    OnlineMarketplaceFacade facade = new OnlineMarketplaceFacade();

    ProductFactory factory = new ProductFactory();

    Product product;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        allOrders();
        facade.updateObservers();
        facade.notifyUsers("today black friday!!!");
        priceBut.setOnMouseClicked(e->{
            if(Sweatshirt1.isSelected()||Sweatshirt2.isSelected()||Sweatshirt3.isSelected()||Sweatshirt4.isSelected()
                    ||Sweatshirt5.isSelected()||Sweatshirt6.isSelected()||Sweatshirt7.isSelected()){
                product = factory.createProduct("Sweatshirt");
                price.setText(product.getPrice()+"");
            }
            else if(Hoodie1.isSelected()||Hoodie2.isSelected()||Hoodie3.isSelected()||Hoodie4.isSelected()
                    ||Hoodie5.isSelected()||Hoodie6.isSelected()||Hoodie7.isSelected()||Hoodie8.isSelected()){
                product = factory.createProduct("Hoodie");
                price.setText(product.getPrice()+"");
            }
            else if(Tshirt1.isSelected()||Tshirt2.isSelected()||Tshirt3.isSelected()||Tshirt4.isSelected()
                    ||Tshirt5.isSelected()||Tshirt6.isSelected()){
                product = factory.createProduct("T-Shirt");
                price.setText(product.getPrice()+"");
            }
            else if(Shopper1.isSelected()||Shopper2.isSelected()||Shopper3.isSelected()||Shopper4.isSelected()
                    ||Shopper5.isSelected()||Shopper6.isSelected()||Shopper7.isSelected()||Shopper8.isSelected()){
                product = factory.createProduct("Shopper");
                price.setText(product.getPrice()+"");
            }
            else if(Cap1.isSelected()||Cap2.isSelected()){
                product = factory.createProduct("Cap");
                price.setText(product.getPrice()+"");
            }
            else if(Cup1.isSelected()||Cup2.isSelected()||Cup3.isSelected()||Cup4.isSelected()){
                product = factory.createProduct("Cup");
                price.setText(product.getPrice()+"");
            }
            else if(Panama1.isSelected()||Panama2.isSelected()){
                product = factory.createProduct("Panama");
                price.setText(product.getPrice()+"");
            }
            else if(ALKI1.isSelected()||ALKI2.isSelected()||ALKI3.isSelected()||ALKI4.isSelected()||ALKI5.isSelected()
                    ||ALKI6.isSelected()||ALKI7.isSelected()) {
                product = factory.createProduct("ALKI");
                price.setText(product.getPrice() + "");
            }
        });
//        sdu1.setImage(new Image("C:\\Users\\sanzh\\Downloads\\Telegram Desktop\\IMG_20231217_195808.jpg"));
//        sdu2.setImage(new Image("C:\\Users\\sanzh\\Downloads\\Telegram Desktop\\IMG_20231222_030822.jpg"));
//        sdu1.setImage(new Image("C:\\Users\\sanzh\\Downloads\\Telegram Desktop\\IMG_20231222_024300.jpg"));
    }

    @FXML
    void buyIt(ActionEvent event) {
        Stage stage = new Stage();
        Text buy = new Text();
        if((L.isSelected() || M.isSelected() || S.isSelected()) && !price.getText().isEmpty()){
        buy.setText("purchase completed");
        buy.setFill(Color.web("#00FF2A"));
        facade.placeOrder(product.getType());
        User user = new User(lastVisitor());
        facade.addObserver(user);
       }
        else{
          buy.setText("you didn't select size or product");
          buy.setFill(Color.web("#ff5a5a"));
        }
        stage.setScene(new Scene(new StackPane(buy), 200, 50));
        stage.show();
    }

    @FXML
    void ALKI(ActionEvent event) {
        im1.setImage(new Image("C:\\Users\\sanzh\\OneDrive\\Изображения\\Screenshot 2023-12-18 193415.png"));
        L.setVisible(true);
        M.setVisible(true);
        S.setVisible(true);
        price.setVisible(true);
        buy.setVisible(true);
        off();
        ALKI1.setVisible(true);
        ALKI2.setVisible(true);
        ALKI3.setVisible(true);
        ALKI4.setVisible(true);
        ALKI5.setVisible(true);
        ALKI6.setVisible(true);
        ALKI7.setVisible(true);

    }

    @FXML
    void CupCapPanama(ActionEvent event) {
        im1.setImage(new Image("C:\\Users\\sanzh\\OneDrive\\Изображения\\Screenshot 2023-12-18 193344.png"));
        L.setVisible(false);
        M.setVisible(false);
        S.setVisible(false);
        price.setVisible(true);
        buy.setVisible(true);
        off();
        Cup1.setVisible(true);
        Cup2.setVisible(true);
        Cup3.setVisible(true);
        Cup4.setVisible(true);
        Cap1.setVisible(true);
        Cap2.setVisible(true);
        Panama1.setVisible(true);
        Panama2.setVisible(true);
    }

    @FXML
    void Hoodies(ActionEvent event) {
        im1.setImage(new Image("C:\\Users\\sanzh\\OneDrive\\Изображения\\Screenshot 2023-12-18 191913.png"));
        L.setVisible(true);
        M.setVisible(true);
        S.setVisible(true);
        price.setVisible(true);
        buy.setVisible(true);
        off();
        Hoodie1.setVisible(true);
        Hoodie2.setVisible(true);
        Hoodie3.setVisible(true);
        Hoodie4.setVisible(true);
        Hoodie5.setVisible(true);
        Hoodie6.setVisible(true);
        Hoodie7.setVisible(true);
        Hoodie8.setVisible(true);
    }

    @FXML
    void ShopperBag(ActionEvent event) {
        im1.setImage(new Image("C:\\Users\\sanzh\\OneDrive\\Изображения\\Screenshot 2023-12-18 193323.png"));
        L.setVisible(false);
        M.setVisible(false);
        S.setVisible(false);
        price.setVisible(true);
        buy.setVisible(true);
        off();
        Shopper1.setVisible(true);
        Shopper2.setVisible(true);
        Shopper3.setVisible(true);
        Shopper4.setVisible(true);
        Shopper5.setVisible(true);
        Shopper6.setVisible(true);
        Shopper7.setVisible(true);
        Shopper8.setVisible(true);
    }

    @FXML
    void Sweatshirts(ActionEvent event) {
        im1.setImage(new Image("C:\\Users\\sanzh\\OneDrive\\Изображения\\sw.png"));
        L.setVisible(true);
        M.setVisible(true);
        S.setVisible(true);
        price.setVisible(true);
        buy.setVisible(true);
        off();
        Sweatshirt1.setVisible(true);
        Sweatshirt2.setVisible(true);
        Sweatshirt3.setVisible(true);
        Sweatshirt4.setVisible(true);
        Sweatshirt5.setVisible(true);
        Sweatshirt6.setVisible(true);
        Sweatshirt7.setVisible(true);
    }
    @FXML
    void Tshirts(ActionEvent event) {
        im1.setImage(new Image("C:\\Users\\sanzh\\OneDrive\\Изображения\\Screenshot 2023-12-18 192321.png"));
        L.setVisible(true);
        M.setVisible(true);
        S.setVisible(true);
        price.setVisible(true);
        buy.setVisible(true);
        off();
        Tshirt1.setVisible(true);
        Tshirt2.setVisible(true);
        Tshirt3.setVisible(true);
        Tshirt4.setVisible(true);
        Tshirt5.setVisible(true);
        Tshirt6.setVisible(true);
    }

    @FXML
    void instagramIn(ActionEvent event) {
        if (Desktop.isDesktopSupported()) {
            Desktop desktop = Desktop.getDesktop();
            try {
                URI uri = new URI("https://www.instagram.com/sdu.store/");
                desktop.browse(uri);
            } catch (IOException excp) {
                excp.printStackTrace();
            } catch (URISyntaxException excp) {
                excp.printStackTrace();
            }
        }
    }
    @FXML
    void Notification(ActionEvent event) {
        String filePath = "Folder/notify";

        String user = lastVisitor();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String currentLine;

            while ((currentLine = reader.readLine()) != null) {
                if (currentLine.contains(user)) {
                    Stage stage = new Stage();
                    Text notify = new Text();
                    notify.setText(currentLine);
                    notify.setFill(Color.web("#ff5a5a"));
                    stage.setScene(new Scene(new StackPane(notify), 400, 200));
                    stage.show();
                    break;
                }
            }

        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
        }
    }

    public String lastVisitor(){
        String filePath = "Folder/allVisits";
        String userLogin = null;
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String current;
            while ((current = reader.readLine()) != null) {
                userLogin = current;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return userLogin;
    }

    public void allOrders(){
        String lastVisitor = lastVisitor();
        String filePath = "Folder/"+lastVisitor+".txt";
        String targetWord = "Orders:";
        boolean foundTargetWord = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String currentLine;
            while ((currentLine = reader.readLine()) != null) {
                if (foundTargetWord) {
                    orders.setText(orders.getText()+"\n"+currentLine);
                }
                if (currentLine.contains(targetWord)) {
                    foundTargetWord = true;
                }
            }

        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
        }
    }
     void off(){
         Tshirt1.setVisible(false);
         Tshirt2.setVisible(false);
         Tshirt3.setVisible(false);
         Tshirt4.setVisible(false);
         Tshirt5.setVisible(false);
         Tshirt6.setVisible(false);
         Sweatshirt1.setVisible(false);
         Sweatshirt2.setVisible(false);
         Sweatshirt3.setVisible(false);
         Sweatshirt4.setVisible(false);
         Sweatshirt5.setVisible(false);
         Sweatshirt6.setVisible(false);
         Sweatshirt7.setVisible(false);
         Shopper1.setVisible(false);
         Shopper2.setVisible(false);
         Shopper3.setVisible(false);
         Shopper4.setVisible(false);
         Shopper5.setVisible(false);
         Shopper6.setVisible(false);
         Shopper7.setVisible(false);
         Shopper8.setVisible(false);
         Hoodie1.setVisible(false);
         Hoodie2.setVisible(false);
         Hoodie3.setVisible(false);
         Hoodie4.setVisible(false);
         Hoodie5.setVisible(false);
         Hoodie6.setVisible(false);
         Hoodie7.setVisible(false);
         Hoodie8.setVisible(false);
         Cup1.setVisible(false);
         Cup2.setVisible(false);
         Cup3.setVisible(false);
         Cup4.setVisible(false);
         Cap1.setVisible(false);
         Cap2.setVisible(false);
         Panama1.setVisible(false);
         Panama2.setVisible(false);
         ALKI1.setVisible(false);
         ALKI2.setVisible(false);
         ALKI3.setVisible(false);
         ALKI4.setVisible(false);
         ALKI5.setVisible(false);
         ALKI6.setVisible(false);
         ALKI7.setVisible(false);
         priceBut.setVisible(true);

     }
}


