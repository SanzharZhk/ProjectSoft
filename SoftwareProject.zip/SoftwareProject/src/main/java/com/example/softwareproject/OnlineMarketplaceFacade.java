package com.example.softwareproject;

import java.io.IOException;

public class OnlineMarketplaceFacade {
    private OrderCommand orderCommand;
    private ProductFactory productFactory;
    private OrderStatusSubject orderStatusSubject;
    private User user;

    public OnlineMarketplaceFacade() {
        this.orderCommand = new OrderCommand();
        this.productFactory = new ProductFactory();
        this.orderStatusSubject = new OrderStatusSubject();
    }

    // Command Design Pattern
    public void placeOrder(String productType) {
        Product product = productFactory.createProduct(productType);
        try {
            orderCommand.execute(new PlaceOrderCommand(product, user));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    // Observer Design Pattern
    public void addObserver(OrderStatusObserver observer) {
        orderStatusSubject.addObserver(observer);
    }
    public void notifyUsers(String message){
        orderStatusSubject.notifyObservers(message);
    }

    public void updateObservers(){
        orderStatusSubject.updateObservers();
    }
}